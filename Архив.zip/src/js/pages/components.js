console.log('components page');
import "../modules/test";