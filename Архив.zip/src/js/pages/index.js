console.log('Webpack + Pug starter')
import "../modules/test";